ITA: Buonasera a tutti, Mi presento sono Luca ho 16 Anni ed è da un'pò di tempo che sono  entrato nel mondo dello "script" in ambito FiveM, 
     inoltre tra pochi giorni rilascerò il Nuovo Server Discord dove potete entrare tutti 
     e anche qualche Lavoretto fatto Completamente da me e scaricabile.


ENG: Good evening everyone, I introduce myself, I am Luca, I am 16 years old and it has been a while since I entered the world of the "script" in the FiveM environment,
     also in a few days I will release the New Discord Server where you can all enter
     and also some work done completely by me and downloadable.


    📞| CONTATTI |📞

    -DISCORD: !Luca®#2171
    
